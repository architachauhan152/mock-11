import React, { useEffect, useState } from "react";
import { FaUserInjured } from "react-icons/fa";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { filterList, getPatientList, sortList } from "../Redux/Action/action";
import { Pagination } from "./Pagination";

export const PatientList = () => {
  const list = useSelector((state) => state.patientList);
  const [open, setOpen] = useState(false);
  const [sort, setSort] = useState(false);
  console.log(list);

  const navigate = useNavigate();
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getPatientList());
  }, []);

  const handleMale = () => {
    dispatch(filterList(1));
    navigate("/filter/gender/Male");
  };
  const handleFemale = () => {
    dispatch(filterList(2));
    navigate("/filter/gender/Female");
  };
  const handleAsc = () => {
    dispatch(sortList(1));
    navigate("/sort/age/Ascending");
  };
  const handleDes = () => {
    dispatch(sortList(2));
    navigate("/sort/age/Descending");
  };
  return (
    //
    <div>
      <div>
        {open ? (
          <div>
            <div onClick={handleMale}>Male</div>
            <hr />
            <div onClick={handleFemale}>Female</div>
          </div>
        ) : null}
        <button
          onClick={() => {
            setOpen(!open);
          }}
        >
          <span>Filter By Gender</span>
        </button>
        <button
          onClick={() => {
            setSort(!sort);
          }}
        >
          <span>Sort By Age</span>
        </button>
        {sort ? (
          <div>
            <div onClick={handleAsc}>Asceding</div>
            <hr />
            <div onClick={handleDes}>Descending</div>
          </div>
        ) : null}
      </div>
      {list?.map((item) => {
        return (
          <div>
            <div>
              <span>
                <FaUserInjured className="mt-1" />
              </span>
              {item.name}
            </div>
            <div className="mt-2">{item.age}</div>
            <div>{item.gender}</div>
            <div>
              Medicine <span>/ {item.medicine.length}</span>
            </div>
            <div>
              <button>
                <span>Details</span>
              </button>
            </div>
          </div>
        );
      })}
      <Pagination />
    </div>
  );
};
