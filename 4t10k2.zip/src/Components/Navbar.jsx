import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { logout } from "../Redux/Action/action";
export const Navbar = () => {
  const user = useSelector((state) => state.doctorLogin);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const handleLogout = () => {
    dispatch(logout());
  };
  return (
    <div>
      <h1>Hospital Records</h1>
      <div>{user?.name}</div>
      <div>
        {user ? (
          <button onClick={handleLogout} type="button">
            Logout
          </button>
        ) : (
          <div>
            <button
              onClick={() => {
                navigate("/signup");
              }}
              type="button"
            >
              Singup
            </button>
            <button
              onClick={() => {
                navigate("/login");
              }}
              type="button"
            >
              Login
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
