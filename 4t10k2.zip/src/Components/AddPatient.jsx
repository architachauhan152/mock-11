import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { postPatient } from "../Redux/Action/action";

export const AddPatient = () => {
  const [patient, setPatient] = useState({
    name: "",
    gender: "Male",
    age: 0,
    medicinename: "",
    quantity: 0
  });
  const dispatch = useDispatch();
  const handleClick = () => {
    let object = {
      name: patient.name,
      gender: patient.gender,
      age: patient.age,
      medicine: [
        {
          name: patient.medicinename,
          quantity: patient.quantity
        }
      ]
    };
    console.log(object);
    dispatch(postPatient(object));
  };
  return (
    <div>
      <input
        onChange={(e) => {
          setPatient({ ...patient, name: e.target.value });
        }}
        type="text"
        placeholder="PatientName.."
      />
      <select
        onChange={(e) => {
          console.log(e.target.value);
          setPatient({ ...patient, gender: e.target.value });
        }}
        name="Gender"
        id=""
      >
        <option value="Male">Male</option>
        <option value="Female">Female</option>
      </select>
      <input
        onChange={(e) => {
          setPatient({ ...patient, age: e.target.value });
        }}
        type="number"
        placeholder="Age"
      />
      <input
        onChange={(e) => {
          setPatient({
            ...patient,
            medicinename: e.target.value
          });
        }}
        type="text"
        placeholder="Medicine Name..."
      />
      <input
        onChange={(e) => {
          setPatient({
            ...patient,
            quantity: e.target.value
          });
        }}
        type="number"
        placeholder="Quantity..."
      />
      <button onClick={handleClick}>Button</button>
    </div>
  );
};
