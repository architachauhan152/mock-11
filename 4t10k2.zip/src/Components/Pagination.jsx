import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { getPatientList } from "../Redux/Action/action";

export const Pagination = () => {
  const [page, setPage] = useState([]);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const handlePage = (i) => {
    console.log(i);
    navigate(`/page/${i}`);
    dispatch(getPatientList(i));
  };
  return (
    <div>
      {page.map((item) => {
        return (
          <>
            <div
              onClick={() => {
                handlePage(item);
              }}
            >
              {item}
            </div>
          </>
        );
      })}
    </div>
  );
};
