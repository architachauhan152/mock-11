import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { signgnup, signupDoctor } from "../Redux/Action/action";

export const SignUp = () => {
  const [user, setUser] = useState({
    name: "",
    email: "",
    password: "",
  });
  const dispatch = useDispatch()
  const handlesignIn = () => {
    dispatch(signupDoctor(user))
  };
  return (
    <div>
      <input
        onChange={(e) => {
          setUser({ ...user, name: e.target.value });
        }}
        type="text"
        placeholder="Name.."
      />
      <input
        onChange={(e) => {
          setUser({ ...user, email: e.target.value });
        }}
        type="email"
        placeholder="Email.."
      />
      <input
        onChange={(e) => {
          setUser({ ...user, password: e.target.value });
        }}
        type="password"
        placeholder="password.."
      />
      <button
        onClick={handlesignIn}
      >
        Singup
      </button>
    </div>
  );
};