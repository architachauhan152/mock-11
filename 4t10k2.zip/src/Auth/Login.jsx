import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { loginDoctore } from "../Redux/Action/action";

export const Login = () => {
  const [user, setUser] = useState({
    email: "",
    password: "",
  });
  const dispatch = useDispatch();
  const handlesignIn = () => {
    dispatch(loginDoctore(user));
  };


  
  return (
    <div>
      <input
        onChange={(e) => {
          setUser({ ...user, email: e.target.value });
        }}
        type="email"
        placeholder="enter Email"
      />
      <input
        onChange={(e) => {
          setUser({ ...user, password: e.target.value });
        }}
        type="password"
        placeholder="enter password"
      />
      <button
        onClick={handlesignIn}
      >
        Login
      </button>
    </div>
  );
};