import {
  CREATEPATIENT,
  FILTER,
  GETPATIENT,
  LOGIN,
  LOGOUT,
  SIGNUP,
  SORT,
} from "../ActionType/actiontype";
import axios from "axios";

export const createPatient = (payload) => {
  return {
    type: CREATEPATIENT,
    payload,
  };
};

export const signup = (payload) => {
  return {
    type: SIGNUP,
    payload,
  };
};

export const login = (payload) => {
  return {
    type: LOGIN,
    payload,
  };
};

export const logout = () => {
  return { type: LOGOUT };
};

export const getPatients = (payload) => {
  return { type: GETPATIENT, payload };
};
export const filter = (payload) => {
  return {
    type: FILTER,
    payload,
  };
};
export const sort = (payload) => {
  return {
    type: SORT,
    payload,
  };
};
export const postPatient = (obj) => (dispatch) => {
  axios
    .post("http://localhost:8080/createPatient", obj)
    .then((res) => {
      console.log(res.data);
    })
    .catch((err) => {
      console.log(err);
    });
};

export const signupDoctor = (obj) => (dispatch) => {
  axios
    .post("http://localhost:8080/signup", obj)
    .then((res) => {
      console.log(res.data);
    })
    .catch((err) => {
      console.log(err);
    });
};
export const loginDoctore = (obj) => (dispatch) => {
  axios
    .post("http://localhost:8080/login", obj)
    .then((res) => {
      console.log(res.data);
      dispatch(login(res.data));
    })
    .catch((err) => {
      console.log(err);
    });
};

export const getPatientList = (id) => (dispatch) => {
  const num = id || 1;
  axios
    .get(`http://localhost:8080/patientList/${num}`)
    .then((res) => {
      console.log(res.data);
      dispatch(getPatients(res.data));
    })
    .catch((err) => {
      console.log(err);
    });
};

export const filterList = (id) => (dispatch) => {
  axios
    .get(`http://localhost:8080/patientList/filter/gender/${id}`)
    .then((res) => {
      console.log(res.data);
      dispatch(filter(res.data));
    })
    .catch((err) => {
      console.log(err);
    });
};
export const sortList = (id) => (dispatch) => {
  axios
    .get(`http://localhost:8080/patientList/sort/age/${id}`)
    .then((res) => {
      console.log(res.data);
      dispatch(sort(res.data));
    })
    .catch((err) => {
      console.log(err);
    });
};