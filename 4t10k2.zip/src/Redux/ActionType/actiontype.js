export const SIGNUP = "SIGNUP";
export const LOGIN = "LOGIN";
export const CREATEPATIENT = "CREATEPATIENT";
export const LOGOUT = "LOGOUT";
export const GETPATIENT = "GETPATIENT";
export const FILTER = "FILTER";
export const SORT = "SORT";
