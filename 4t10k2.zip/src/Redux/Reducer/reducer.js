import {
  CREATEPATIENT,
  FILTER,
  GETPATIENT,
  LOGIN,
  LOGOUT,
  SIGNUP,
  SORT
} from "../ActionType/actiontype";

const initialState = {
  patientList: [],
  doctorLogin: null
};

export const reducer = (state = initialState, { type, payload }) => {
  switch (type) {
    case LOGIN:
      return {
        ...state,
        doctorLogin: payload
      };
    case CREATEPATIENT:
      return {
        ...state,
        patientList: payload
      };
    case LOGOUT:
      return {
        ...state,
        doctorLogin: null
      };
    case GETPATIENT:
      return {
        ...state,
        patientList: payload
      };
    case FILTER:
    case SORT:
      return {
        ...state,
        patientList: payload
      };
    default:
      return state;
  }
};
