import { Login } from "./Auth/Login";
import { SignUp } from "./Auth/SignUp";
import { AddPatient } from "./Components/AddPatient";
import { Navbar } from "./Components/Navbar";
import { PatientList } from "./Components/PatientList";
import { Routes, Route } from "react-router-dom";
function App() {
  return (
    <div>
      <Navbar />
      <Routes>
        <Route path="/" exact element={<PatientList />} />
        <Route path="/page/:id" element={<PatientList />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/login" element={<Login />} />
        <Route path="/AddPatient" element={<AddPatient />} />
        <Route path="/filter/gender/:id" element={<PatientList />} />
        <Route path="/sort/age/:id" element={<PatientList />} />
      </Routes>
    </div>
  );
}

export default App;
